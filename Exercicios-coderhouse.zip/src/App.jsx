import './index.css'
import Navbar from './components/Navbar'

function App() {

  return (
    <>
        <div>
         <Navbar/>
        </div>
        <div>
          Teste
        </div>
    </>
  )
}

export default App
