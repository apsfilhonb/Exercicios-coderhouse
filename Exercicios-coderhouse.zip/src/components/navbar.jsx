import React from 'react'
import { useDisclosure } from '@mantine/hooks';
import { Modal, Popover, Text, Button, Drawer } from '@mantine/core';


function Navbar() {
    const [opened, { open, close }] = useDisclosure(false);
    return (
        <>
            <nav className="flex w-full bg-slate-100 justify-evenly">
                <img width="60px" height="auto" src="https://seeklogo.com//images/T/ti-wheels-logo-DF6252D47D-seeklogo.com.png" />
                <ul className="flex items-center w-[60rem] justify-evenly">
                    <li className="text-3xl font-bold ">SWITCHS</li>
                    <li className="text-3xl font-bold ">UNIFI</li>
                    <li className="text-3xl font-bold ">POE</li>
                </ul>
                <Modal opened={opened} onClose={close} title="Authentication">
                    {/* Modal content */}
                </Modal>

                <Button onClick={open}>
                    <img width="60px" src='https://cdn-icons-png.flaticon.com/512/6713/6713723.png'/>
                    <Text size="sm">Carrinho</Text>
                </Button>


            </nav>
        </>
    )
}

export default Navbar